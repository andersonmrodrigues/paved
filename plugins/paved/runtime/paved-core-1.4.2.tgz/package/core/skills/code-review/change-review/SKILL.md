---
name: change-review
description: >-
  Reviews a finished change before completion across correctness, scope, architecture,
  consistency, maintainability, tests, security, performance and evidence. Use when a
  change reaches the review phase of a workflow, or when a human asks for a review.
---

# Change review

## When to use

In the `review` phase, after verification and evidence. Also when a human asks for a
review of a change made by anyone.

## Required context

None is required beyond the diff and its evidence record. Useful: the rules that apply
to the changed files and the architecture context.

## Preconditions

Verification has run and an evidence record exists (it may be incomplete).

## Procedure

Read the diff with `core.repository.diff` top to bottom, confirm with `core.repository.status` that
nothing is left out, then go through each dimension. Stop at none; note findings as you
go.

1. **Scope**: every hunk is explained by the task; nothing unrelated rode along.
2. **Correctness**: the code does what the claims say, including absent or empty
   values, boundaries, error paths, concurrency and resource cleanup.
3. **Architecture**: dependencies respect declared boundaries; responsibilities sit in
   the layer where siblings put them.
4. **Consistency**: naming, structure, error handling and logging match the siblings.
5. **Maintainability**: no dead code, debug output or leftovers; no duplication a reader
   would have to keep in sync; comments explain why, not what.
6. **Tests**: they assert the claimed behavior, including the edge cases from step 2,
   and would fail if the behavior broke.
7. **Security**: if the change touches input, access control, sensitive data,
   configuration or dependencies, run `security-review`.
8. **Performance**: look for work inside loops that could be done once, unbounded
   growth, and new remote calls on hot paths.
9. **Evidence**: each supporting check actually exercises its claim. A passing suite
   that never touches the changed code supports nothing.
10. **Rules**: compliance entries in the evidence match the diff.

Fix findings in scope, then re-run the checks the fixes affect. Record the rest.

## Tools

`core.repository.diff` and `core.repository.status`.

## Rules

All rules in scope; `core.architecture.follow-existing-patterns` for step 4 and
`core.quality.evidence-before-completion` for step 9.

## Verification

None is required of the review itself. Recommended: `static-analysis` on the final diff.
Any fix made during review is verified like any other change.

## Evidence

A review artifact with findings, their severity and their resolution. The agent's own
review supports no claim; it prepares the human review.

## Completion criteria

- No unexplained hunk in the diff.
- Every claim's support was confirmed to exercise the claim.
- Findings are fixed, or recorded with a reason.

## Failure modes

| Failure | Signal | Response |
|---|---|---|
| Rubber stamp | Review finds nothing in a non-trivial diff | Go through steps 2 and 9 explicitly |
| Evidence theater | Claims backed by checks unrelated to the change | Downgrade the claim or add a real check |
| Style over substance | Findings are all about formatting | Revisit correctness and tests first |

## References

None.
