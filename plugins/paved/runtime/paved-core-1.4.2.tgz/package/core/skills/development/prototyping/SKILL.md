---
name: prototyping
description: >-
  Builds a small, deliberately temporary implementation to answer a question (is this
  feasible, which approach works, what does a dependency really return) and reports the
  answer. Use when a human asks for a spike, proof of concept or experiment, not for code
  meant to ship.
---

# Prototyping

## When to use

A human asked for a prototype, spike or proof of concept, or planning cannot continue
without answering a feasibility question. A prototype answers a question; it is not an
early version of the feature.

## Required context

The question to answer. Useful: the technology context, to prototype with what the
project already uses.

## Preconditions

- The question and the answer that would settle it are written down ("the external
  service accepts batches of at least N items").
- A human agreed on where the prototype lives and when it is removed.

## Procedure

1. **Scope.** Write the question, what is out of scope, and a time box.
2. **Isolate.** Put the prototype where it cannot ship by accident: a separate branch or
   directory the build excludes, clearly labeled as a prototype at the top of each file.
3. **Accept shortcuts, explicitly.** Allowed: hard-coded inputs, no error handling, no
   tests beyond what shows the answer. Never allowed: real secrets in files, production
   data, writes to shared environments, weakened checks in the main code.
4. **Run it** and record what happened: inputs, outputs, how to reproduce it.
5. **Answer the question**: yes, no or partly, with the reproduction as evidence and the
   limits of what the prototype showed.
6. **Clean up or transition.** Delete the prototype, or, if a human decides to build on
   the result, start over through the feature workflow. The prototype is a reference,
   not a starting point; its shortcuts do not move into production code.

## Tools

None. Commands come from the verification profile or the adapters.

## Rules

None beyond those that apply by scope. The shortcuts in step 3 never extend to secrets or
shared environments.

## Verification

Required: `runtime` — the prototype was run and observed. Recommended: `build`, to know
the approach at least compiles in the project's toolchain.

## Evidence

A reproduction (how to run it, what it showed) and the diff, so the prototype can be
found and removed.

## Completion criteria

- The question has an answer, backed by the reproduction, with its limits stated.
- The prototype is deleted, or labeled and scheduled for removal by a human.
- Nothing from the prototype reached the main code.

## Failure modes

| Failure | Signal | Response |
|---|---|---|
| Prototype becomes the product | Someone proposes merging it | Stop; start the feature workflow instead |
| Question drifts | Work continues after the answer is known | Report the answer; stop |
| Unlabeled leftovers | Prototype files outside the agreed place | Move or delete them |
| Answer overstated | Report claims more than the run showed | Restate the limits |

## References

None.
