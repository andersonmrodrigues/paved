---
name: regression-testing
description: >-
  Writes an automated test that reproduces a defect, fails before the fix and passes
  after it, at the lowest level that still captures the bug. Use for every bug fix and
  when turning an incident or reproduction into a permanent guard.
---

# Regression testing

## When to use

After `root-cause-analysis` produced a reproduction, and before the fix is written.

## Required context

The reproduction, the tests near the affected code, and the verification profile (to
know how to run a single test).

## Preconditions

The cause is known well enough to assert the correct behavior.

## Procedure

1. **Choose the lowest level** that reproduces the bug and write the test with that
   level's skill: `unit-testing` if the cause is local, `integration-testing` if it
   lives in the interaction between components, `e2e-testing` only if nothing lower
   captures it.
2. **Name the test after the behavior**, not after the ticket.
3. **Run it against the unfixed code** and confirm it **fails for the right reason**
   (the assertion about the bug, not a setup error). Record that failure.
4. **After the fix**, run it again, confirm it passes, then run the surrounding suite.

## Tools

None. The targeted test command comes from the verification profile.

## Rules

`core.testing.regression-test-for-bug-fix` is this skill's contract.

## Verification

Required: `unit`. Recommended: `integration` or `e2e` when the test lives at that level;
when it does, record the `unit` requirement as a gap naming the level used.

## Evidence

A check result for the new test whose summary states it failed before the fix, and a
check result for the surrounding suite.

## Completion criteria

- The test failed before the fix for the reason the bug describes.
- The test passes after the fix, and the surrounding suite passes.

## Failure modes

| Failure | Signal | Response |
|---|---|---|
| Test passes before the fix | It does not reproduce the bug | Rework the test before fixing anything |
| Fails for the wrong reason | Setup or fixture error before the assertion | Fix the test setup |
| Too high level | Slow or flaky end-to-end test for a local defect | Move the test down a level |

## References

None.
