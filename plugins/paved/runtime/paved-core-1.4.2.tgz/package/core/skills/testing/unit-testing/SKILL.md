---
name: unit-testing
description: >-
  Writes or updates fast, isolated tests for one unit of logic, following the
  repository's existing test conventions: location, naming, structure, test doubles and
  assertions. Use when code with its own logic is added or changed, or when a claim can
  be proven without real external collaborators.
---

# Unit testing

## When to use

Whenever a development or debugging skill needs a claim about local logic proven. A unit
test runs in isolation from networks, databases, file systems shared with other tests,
clocks and randomness, and runs in well under a second.

## Required context

The verification profile: how the project runs its unit tests, and how to run one test.
Useful: the technology context and adapter knowledge for the test framework in use.

## Preconditions

The behavior to test is stated as a claim with its inputs and expected result.

## Procedure

1. **Discover the conventions** before writing anything: find the tests nearest to the
   code under test and read two or three. Note where they live, how files and tests are
   named, how they are structured (arrange, act, assert or its local equivalent), which
   test doubles and assertion helpers they use, and how fixtures are built.
2. **Choose the cases** from the claim: the expected path, each boundary (empty, one,
   many, limits), invalid input, and each way a collaborator can fail.
3. **Write one test per behavior**, named after the behavior, not after the method. Each
   test fails for one reason.
4. **Replace only what crosses the unit's boundary** with test doubles: remote calls,
   storage, time, randomness. Do not replace the logic being tested.
5. **Assert on outcomes** (returned values, raised errors, recorded calls to
   collaborators that matter), not on internal steps.
6. **Watch each new test fail once**, by running it before the code exists or by breaking
   the code briefly. A test that has never failed has not been shown to test anything.
7. **Run the unit suite** for the affected module and keep it green.

## Tools

None. The command to run tests comes from the verification profile.

## Rules

`core.architecture.follow-existing-patterns` applies to tests as much as to code: a new
test framework, assertion style or fixture mechanism needs a human decision.

## Verification

Required: `unit`.

## Evidence

A check result for the unit suite that contains the new or changed tests.

## Completion criteria

- Every claim assigned to this skill has at least one test asserting it.
- Each new test was seen failing once and now passes.
- The module's unit suite passes.

## Failure modes

| Failure | Signal | Response |
|---|---|---|
| Testing the double | The assertion checks a value the double returned | Assert on the unit's own behavior |
| Brittle test | Test breaks on a refactor that keeps behavior | Assert on outcomes, not internal calls |
| Hidden dependency | Test fails depending on order, time or machine | Remove the shared state or inject it |
| No unit test infrastructure | No existing unit tests to follow | Record a gap; ask before introducing a framework |

## References

None.
