---
name: frontend-design
description: >-
  Plans, builds and critiques user-facing frontend interfaces with visual choices grounded
  in the product, audience and project. Use when creating or materially changing a page,
  component, layout, visual hierarchy, typography, color or motion; skip for backend-only
  work and fixes that do not alter the interface.
---

# Frontend design

## When to use

Use in feature or bug workflows when the planned change affects how people see or use a
frontend interface. For backend-only changes or fixes that preserve the interface, record
the skill as not applicable with the reason.

## Required context

Read the request and acceptance criteria. When available, use product and architecture
context, the feature map, project rules, verification profile, and selected technology
knowledge. If design-system or brand guidance exists in the repository, treat it as the
source of truth.

## Preconditions

Know what the interface is for and who uses it. If the purpose, audience, or a material
visual choice is unclear and cannot be inferred from project context, ask the user before
committing to a direction.

## Procedure

1. State the user need and the part of the interface in scope. Separate requested behavior
   from assumptions about appearance.
2. Inspect nearby screens, shared components, design tokens, content and interaction
   patterns. Preserve them unless the request or evidence calls for a change.
3. In the workflow plan, record a compact direction for the relevant dimensions: visual
   hierarchy, color, type, spacing and layout, content, and interaction or motion. Tie each
   choice to the brief or project context; omit dimensions the task does not affect.
4. Review the direction against the brief before coding. Ask whether the same choices would
   fit an unrelated product, whether each visual element helps understanding, and whether
   the hierarchy matches the importance of the content. Revise choices that have no reason
   beyond habit. Follow explicit user direction even when it asks for a familiar pattern.
5. Implement with the project's existing components and conventions. Keep content useful
   and specific to the task; do not add decoration or motion without a user-facing purpose.
6. Inspect the rendered result at the relevant screen sizes and states. Check keyboard
   operation, visible focus, readable contrast, and reduced-motion behavior. Use the
   project's visual review tools when available; otherwise report what could not be checked.
7. Compare the result with the plan, refine mismatches, then run the applicable verification
   checks. Record visual review evidence when available and list any remaining gaps.

## Tools

Use the applicable project's preview, browser or screenshot tools when they are configured.
If none are available, inspect the implementation and run the project's available checks;
do not claim visual behavior was verified without seeing it.

## Rules

`core.architecture.follow-existing-patterns` applies when choosing how the interface fits
the project's existing structure and conventions.

## Verification

Required: `unit` when the changed interface has testable behavior. Recommended: `e2e` for
important user flows, plus the project's configured build and static-analysis checks.

## Evidence

Record the relevant check results, the diff, and a screenshot or browser observation when
the environment supports visual review. Explain any unverified screen size or state.

## Completion criteria

- The interface change addresses the stated user need and follows the approved design direction.
- Relevant responsive states and interaction/accessibility basics were checked, or their
  verification gaps are recorded.
- Applicable tests and checks pass, and no unrelated visual changes remain.

## Failure modes

| Failure | Signal | Response |
|---|---|---|
| Aesthetic direction is guessed | Purpose, audience or brand choices are unsupported | Read project context or ask the user before implementation |
| Existing design system is bypassed | New styles or components duplicate established patterns | Reuse the existing system or document why the task needs a change |
| Visual quality is claimed without review | No rendered view or interaction was inspected | Run available visual checks or report the gap |

## References

- [Frontend Design skill](https://github.com/anthropics/claude-code/blob/main/plugins/frontend-design/skills/frontend-design/SKILL.md) — inspiration for subject-grounded choices and a plan-review-build-critique loop; this Paved procedure is original.
