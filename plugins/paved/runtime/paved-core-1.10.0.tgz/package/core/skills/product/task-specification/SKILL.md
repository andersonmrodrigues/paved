---
name: task-specification
description: >-
  Turns a request into one or more tracker-ready tasks grounded in the repository: type,
  description, expected result, verifiable acceptance criteria, technical context and,
  for bugs, steps to reproduce. Splits requests too large for one task. Use when someone
  asks to write, specify, detail or break down a task, story, bug or epic for this
  repository.
---

# Task specification

## When to use

When a request, idea, bug report or epic must become work items someone can implement.
To assess a task that already exists use `task-review`. To plan the implementation of a
task that is already specified use `feature-development` or the workflow for its type.

## Required context

None is required. Read what exists: the product and domain context for vocabulary and
users, the feature map to locate the affected area, the architecture context for
boundaries, and the verification profile to know which checks could prove a criterion.
Where a context area is absent, fall back to the code and say so in the task.

## Preconditions

- The request says, or the user can say, what should change for whom. If the expected
  result is unclear, ask one question about it before drafting.
- The request concerns this repository. If the code it describes is elsewhere, say so
  and write only what the repository can support.

## Procedure

1. **Classify** the request as one of the types in
   `references/task-template.md`: Feature, Bug, Improvement or Technical debt.
2. **Clarify** only what changes the task: who is affected, the expected result, and,
   for a bug, how to reproduce it. Ask at most one question at a time; do not ask what
   the repository answers.
3. **Ground it in the repository.** Locate the affected area with
   `core.repository.structure` and read it with `core.repository.files`; activate
   `context-discovery` when the area is unfamiliar. Find the sibling that does something
   similar and the rules and boundaries that apply. For a bug, confirm the described
   flow exists in the code. Record each premise the repository contradicts, and each it
   cannot confirm, before writing.
4. **Size it** with the split criteria in `references/task-quality.md`. When the request
   is too large, propose vertical slices: one task per independently usable outcome,
   ordered, with dependencies stated and the uncertain part first.
5. **Write** each task in the template. Acceptance criteria are observable conditions,
   one per line, including the edge cases the request implies and what must keep
   working. The technical context names only paths that exist or marks them as new.
6. **Check** each task against `references/task-quality.md` and fix what fails. Every
   criterion must name how it would be verified, even when that is a manual check.
7. **Deliver** the text ready to paste into the tracker, followed by the contradicted
   premises and open questions. If a tracker integration is available to the agent,
   show exactly what will be created, ask once, and create the items only after the
   user agrees.

## Tools

`core.repository.structure` to find the affected area and its siblings;
`core.repository.files` to read the code, context and rules the task depends on. A
tracker integration, when the agent has one, is used only after the user confirms.

## Rules

`core.quality.unknowns-stay-unknown` governs step 3: a fact the repository and the user
do not support becomes an open question in the task. `core.architecture.follow-existing-patterns`
decides which sibling the technical context points at.

## Verification

The skill changes no code, so no check is required. Each acceptance criterion states how
it would be verified, so whoever implements the task can plan its proof.

## Evidence

None required. The delivered tasks list the repository sources that informed them.

## Completion criteria

- Every task has a type, description, expected result and acceptance criteria.
- Every acceptance criterion is observable and names how it would be verified.
- Every path, component or endpoint named exists in the repository or is marked as new.
- A bug has steps to reproduce with a starting state, actual and expected result.
- A request too large for one task is delivered as ordered, independently usable tasks.
- Contradicted premises and open questions are listed, not silently resolved.
- Nothing was written to the tracker without the user's confirmation.

## Failure modes

| Failure | Signal | Response |
|---|---|---|
| Invented grounding | A path or component in the task is not in the repository | Remove it or mark it as new |
| Solution posing as outcome | Expected result describes code, not behavior | Restate what the user or system observes |
| Horizontal split | Tasks named after layers that cannot ship alone | Re-slice by outcome |
| Guessed requirement | A criterion no one asked for and the code does not imply | Turn it into an open question |
| Code lives elsewhere | The request names flows this repository does not contain | Say so; specify only what this repository can support |
| Template conflict | The project addendum and the template disagree | Follow the addendum |

## References

- `references/task-template.md`: sections, types and when to omit a section.
- `references/task-quality.md`: quality bar, verifiable criteria, split criteria and grounding.
- `examples/feature-task.md`, `examples/bug-task.md`, `examples/split-epic.md`: synthetic results.
